
// import React, { useState, useEffect } from 'react';
// import { db } from '../firebase.config';
// import { collection, getDocs, query, orderBy, limit } from 'firebase/firestore';
// import { useNavigate } from 'react-router-dom';
// import SwiperCore, { EffectCoverflow, Pagination } from 'swiper';
// import { Swiper, SwiperSlide } from 'swiper/react';
// import 'swiper/swiper-bundle.min.css';
// import 'swiper/swiper.min.css';
// import Spinner from './Spinner';
// import { ImLocation2 } from 'react-icons/im';

// SwiperCore.use([EffectCoverflow, Pagination]);

// const Slider = () => {
//     const [listings, setListings] = useState(null);
//     const [loading, setLoading] = useState(true);
//     const [swiperInitialized, setSwiperInitialized] = useState(false);
//     const navigate = useNavigate();
//     const userPic = 
//     "https://th.bing.com/th/id/R.01a2fb974429f5b93ba993d67894f097?rik=2TH6dxjuaGvyhg&riu=http%3a%2f%2fcdn.onlinewebfonts.com%2fsvg%2fimg_119029.png&ehk=C4aZ0qzmdkDSdlGh0QuwthbcBTM5C6EeXjC7hwYUlPY%3d&risl=&pid=ImgRaw&r=0"

//     useEffect(() => {
//         const fetchListings = async () => {
//                 const listingRef = collection(db, 'listings');
//                 const q = query(listingRef, orderBy('timestamp', 'desc'), limit(5));
//                 const querySnap = await getDocs(q);
//                 let listings = [];
//                 querySnap.forEach((doc) => {
//                     return listings.push({
//                         id: doc.id,
//                         data: doc.data(),
//                     });
//                 });
//                 setListings(listings);
//                 setLoading(false);     
//         };
    
//         fetchListings();
//         console.log(listings === null ? "loading" : listings);

//     }, []);
//     if(loading) {
//         return <Spinner></Spinner>;
//     }

//     return (
//         <>
//         <div style={{width: '100%'}}>
//             {listings === null ? (
//                 <Spinner/>
//             ):(
//                  <Swiper
//                      effect={"coverflow"}
//                      grabCursor={true}
//                      centeredSlides={true}
//                      slidesPerView={1}
//                      coverflowEffect={{
//                          rotate: 50,
//                          stretch: 0,
//                          depth: 100,
//                          modifier: 1,
//                          slideShadows: true,
//                      }}
//                      pagination={true}
//                      className="mySwipe"
//                  >
//                     {listings.map(({ data, id }) => (
//                          <SwiperSlide 
//                          key={id} 
//                          onClick={() => {
//                             navigate(`/category/${data.type}/${id}`);
//                          }}
//                          >
//                             {/* <h6 className='bg-info text--light p-2 m-0'>
//                                 <img alt="user pic" src={userPic} height={35} width={35}/>
//                                 <span className='ms-2'>{data.name}</span>
//                             </h6> */}
//                              <img
//                                  src={data.imgUrls[0]}
//                                  alt={data.name}
//                                  className='slider-img'
//                              />
//                              <h4 className='text-light p-4 m-0'>
//                                 <ImLocation2 size={20} className='ms-2'/> Recently Added :{" "}
//                                 <br></br>
//                                 <span className='ms-4 mt-2'>{data.name}</span>
//                                 <span className='ms-2'>
//                                     Price ($ {data.regularPrice} )
//                                 </span>
//                              </h4>
//                          </SwiperSlide>
//                      ))}
//                  </Swiper>
//              )}
//          </div>
//     </>
//      );
// };

// export default Slider;

import React, { useState, useEffect } from 'react';
import { db } from '../firebase.config';
import { collection, getDocs, query, orderBy, limit } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import SwiperCore, { EffectCoverflow, Pagination } from 'swiper';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import Spinner from './Spinner';
import { ImLocation2 } from 'react-icons/im';
import "../styles/slider.css";
SwiperCore.use([EffectCoverflow, Pagination]);

const Slider = () => {
    const [listings, setListings] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchListings = async () => {
            try {
                const listingRef = collection(db, 'listings');
                const q = query(listingRef, orderBy('timestamp', 'desc'), limit(5));
                const querySnap = await getDocs(q);
                let listings = [];
                querySnap.forEach((doc) => {
                    listings.push({
                        id: doc.id,
                        data: doc.data(),
                    });
                });
                setListings(listings);
                setLoading(false);
            } catch (error) {
                console.error('Error fetching listings:', error);
                setLoading(false); // Set loading to false even if there's an error
            }
        };

        fetchListings();
    }, []);


    useEffect(() => {
        console.log(listings === null ? "loading" : listings);
    }, [listings]);

    if (loading) {
        return <Spinner />;
    }

    return (
        <div style={{ width: '100%' }}>
            <Swiper
                effect={"coverflow"}
                grabCursor={true}
                centeredSlides={true}
                slidesPerView={1}
                coverflowEffect={{
                    rotate: 50,
                    stretch: 0,
                    depth: 100,
                    modifier: 1,
                    slideShadows: true,
                }}
                pagination={true}
                className="mySwipe"
            >
                {listings.map(({ data, id }) => (
                    <SwiperSlide
                        key={id}
                        onClick={() => {
                            navigate(`/category/${data.type}/${id}`);
                        }}
                    >
                        <img
                            src={data.imgUrls[0]}
                            height={550}
                            width={1700}
                            alt={data.name}
                            className='slider-img'
                        />
                        <h4 className='text-light p-4 m-0'>
                            <ImLocation2 size={20} className='ms-2' /> Recently Added :{" "}
                            <br />
                            <span className='ms-4 mt-2'>{data.name}</span>
                            <span className='ms-2'>
                               | Price (Rs {data.regularPrice} )
                            </span>
                        </h4>
                    </SwiperSlide>
                ))}
            </Swiper>
        </div>
    );
};

export default Slider;

