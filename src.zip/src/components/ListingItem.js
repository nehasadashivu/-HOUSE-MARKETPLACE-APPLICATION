// import React from 'react';
// import { Link } from 'react-router-dom';
// import { FaBed } from "react-icons/fa";
// import { FaBath } from "react-icons/fa";
// import "../styles/listingitem.css";
// //import Offers from './../pages/Offers';
// //import App from './../App';

// const ListingItem = ({listing, id, onDelete, onEdit}) => {
//   return (
//     <>
//     <div className='d-flex align-items-center justify-content-center'>
//     <div className='card category-link mb-2'
//     style={{width:"800px"}}>
//     <Link to={`/category/${listing.type}/${id}`}>
//         <div className='row container p-2'>
//             <div className='col-md-5 '>
//                 <img
//                  src={listing.imgUrls[0]} 
//                 // className='img-thumbnail'
                
//                 alt={listing.name} 
//                 height={200} 
//                 width={300}/>
//              </div>
//             <div className='col-md-5 item-card-continer2'>
//             <h4>{listing.name}</h4>
//               <p>{listing.location}</p>
//               <p> 
//                 RS :{" "}
//               {listing.offer 
//               ? listing.discountedPrice 
//               : listing.regularPrice}
//               {" "}
//               {listing.type === 'rent' && ' / Month'}
//               </p>
//               <p>
//                 <FaBed/> 
//                 {listing.bedrooms > 1
//                  ?  ` ${listing.bedrooms} Bedrooms`
//                 : '1 Bedroom'}
//               </p>
//               <p>
//                 <FaBath /> 
//                 {listing.bathrooms > 1
//                  ?  ` ${listing.bathrooms} Bathrooms`
//                 : '1 Bathrooms'}
//               </p>
//               </div>
//               </div>
//               </Link>
//               <div>
//               {onDelete && (
//                  <button 
//                      className='btn btn-danger' 
//                      onClick={() => {
//                      onDelete(listing.id, listing.name);
//                     }}
//                    >
//                       Delete Listing
//                   </button>
//                   )}

//               {onEdit && (
//               <button 
//               className='btn btn-info ms-3' 
//               onClick = {() => 
//               onEdit(listing.id)
//               }
//               >
//               Edit Listing
//               </button>
//               )}

// {onEdit && (
//               <button 
//               className='btn btn-info ms-3' 
//               onClick = {() => 
//               onEdit(listing.id)
//               }
//               >
//               Not Available
//               </button>
//               )}
//             </div>
//         </div>
//     </div>
    
    
//     </>
//   );
// };

// export default ListingItem;

import React from 'react';
import { Link } from 'react-router-dom';
import { FaBed, FaBath } from "react-icons/fa";
import "../styles/listingitem.css";

const ListingItem = ({ listing, id, onDelete, onEdit, onMarkNotAvailable, onMarkAvailable }) => {
  const handleMarkNotAvailable = () => {
    // Call the onMarkNotAvailable function with the listing id
    onMarkNotAvailable(id);
  };
  const handleMarkAvailable = () => {
    // Call the onMarkNotAvailable function with the listing id
    onMarkAvailable(id);
  };

  return (
    <div className='d-flex align-items-center justify-content-center'>
      <div className='card category-link mb-2' style={{ width: "800px" }}>
        <Link to={`/category/${listing.type}/${id}`}>
          <div className='row container p-2'>
            <div className='col-md-5 '>
              <img
                src={listing.imgUrls[0]}
                alt={listing.name}
                height={200}
                width={300}
              />
            </div>
            <div className='col-md-5 item-card-continer2'>
              <h4>{listing.name}</h4>
              <p>{listing.location}</p>
              <p> 
                RS :{" "}
                {listing.offer ? listing.discountedPrice : listing.regularPrice}
                {" "}
                {listing.type === 'rent' && ' / Month'}
              </p>
              <p>
                <FaBed/> 
                {listing.bedrooms > 1
                  ?  ` ${listing.bedrooms} Bedrooms`
                  : '1 Bedroom'}
              </p>
              <p>
                <FaBath /> 
                {listing.bathrooms > 1
                  ?  ` ${listing.bathrooms} Bathrooms`
                  : '1 Bathroom'}
              </p>
            </div>
          </div>
        </Link>
        <div>
          {onDelete && (
            <button 
              className='btn btn-danger' 
              onClick={() => onDelete(id, listing.name)}
            >
              Delete Listing
            </button>
          )}
          {onEdit && (
            <button 
              className='btn btn-info ms-3' 
              onClick={() => onEdit(id)}
            >
              Edit Listing
            </button>
          )}
          {onMarkNotAvailable && (
            <button 
              className='btn btn-info ms-3' 
              onClick={handleMarkNotAvailable}
            >
              Not Available
            </button>
          )}
                    {onMarkAvailable && (
            <button 
              className='btn btn-info ms-3' 
              onClick={handleMarkAvailable}
            >
              Mark Available
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ListingItem;
