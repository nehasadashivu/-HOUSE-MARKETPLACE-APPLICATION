// import React from 'react';
// import { Link,NavLink } from "react-router-dom";
// import { BsGithub } from "react-icons/bs";
// import { BsInstagram } from "react-icons/bs";
// import { BsTelegram } from "react-icons/bs";
// import { BsYoutube } from "react-icons/bs";
// import "../../styles/footer.css";


// const Footer = () => {
//   // nk-baconst img1 = "https://thumbs.dreamstime.com/b/white-heart-pickground-7861744.jpg" 
//   return (
//     <div className=' footer mt-4 d-flex align-items-center justify-content-center bg-dark text-light p-4'>
//       {/* <h3>
//         <img 
//         src= {img1}
//         alt ="love"
//         height={60}
//         width={80}
//         className='mx-3'/>
//       </h3> */}
//       <p>
//       <h6>All Right Reserved &copy; House marketPlace- 2024 </h6>
//     </p>
//       <div className='d-flex flex-row p-2'>
//         <p className='me-4' title='Github'>
//           <Link to="/">
//             <BsGithub color = 'black' size={30}></BsGithub>
//           </Link>
//         </p>
//         <p className='me-4' title='Instagram'>
//           <Link to="/">
//             <BsInstagram color='black' size={30}/>
//           </Link>
//         </p>
//         <p className='me-4' title='Telegram'>
//           <Link to="/">
//             <BsTelegram color='black' size={30}/>
//           </Link>
//         </p>
//         <p className='me-4' title='Youtube'>
//           <Link to="/">
//             <BsYoutube color='black' size={30}/>
//           </Link>
//         </p>

//       </div>
//       </div>
//   );
// };

// export default Footer;

import React from 'react';
import { Link } from "react-router-dom";
import { FaGithub, FaInstagram, FaTelegram, FaYoutube } from "react-icons/fa"; // Assuming you're using Font Awesome icons
import "../../styles/footer.css";

const Footer = () => {
  return (
    <div className='footer mt-4 bg-dark text-light p-4 d-flex flex-column align-items-center justify-content-center'>
      {/* Uncomment this section if you want to use the image */}
      {/* <h3>
        <img 
          src="https://thumbs.dreamstime.com/b/white-heart-pickground-7861744.jpg"
          alt="love"
          height={60}
          width={80}
          className='mx-3'/>
      </h3> */}
      <p className="text-center mb-3">
        <h6>All Rights Reserved &copy; House Marketplace - 2024</h6>
      </p>
      <div className='d-flex flex-row justify-content-center align-items-center p-2'>
        <Link to="/" className='me-4' title='Github'>
          <FaGithub color='white' size={30} />
        </Link>
        <Link to="/" className='me-4' title='Instagram'>
          <FaInstagram color='white' size={30} />
        </Link>
        <Link to="/" className='me-4' title='Telegram'>
          <FaTelegram color='white' size={30} />
        </Link>
        <Link to="/" className='me-4' title='Youtube'>
          <FaYoutube color='white' size={30} />
        </Link>
      </div>
    </div>
  );
};

export default Footer;

