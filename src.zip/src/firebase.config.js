import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';


const firebaseConfig = {
  apiKey: "AIzaSyApgZkWV9c97y9Bu1i887Hcqff0sdz0q2o",
  authDomain: "housmarkets.firebaseapp.com",
  projectId: "housmarkets",
  storageBucket: "housmarkets.appspot.com",
  messagingSenderId: "560623032522",
  appId: "1:560623032522:web:28fc128b37621b4b4b3c33"
};



const app = initializeApp(firebaseConfig); 


export const db = getFirestore() ;
