import React, { useState, useEffect } from "react";
import Layout from '../components/Layout/Layout'
import { db } from "../firebase.config";
import { getAuth, updateProfile } from "firebase/auth";
import { toast } from 'react-toastify';
import { doc, updateDoc, getDocs, collection, query, where, orderBy } from "firebase/firestore";
import ListingItem from "../components/ListingItem";

function History() {
    const auth = getAuth();
    const [listings, setListings] = useState(null);

    
    const onMarkAvailable = async (listingId) => {
      try {
        // Update listing status to not available in Firestore
        const listingRef = doc(db, 'listings', listingId);
        await updateDoc(listingRef, { available: "true" });
        // Update the listings state to reflect the change
        const updatedListings = listings.filter((listItem) => {
          return listItem.id !== listingId;
        })
        setListings(updatedListings);
        toast.success('Listing marked as available.');
      } catch (error) {
        console.error(error);
        toast.error('Failed to mark listing as not available.');
      }
    };

    useEffect(() => {
        const fetchUserListings = async () => {
          const listingRef = collection(db, 'listings');
          const q = query(
            listingRef,
            where('useRef', '==', auth.currentUser.uid),
            orderBy('timestamp', 'desc')
          );
          const querySnap = await getDocs(q);
    
          let listings = [];
          querySnap.forEach((doc) => {
            if(doc.data().available == "false") {

                listings.push({
                    id: doc.id,
                    data: doc.data(),
                  });
            }
          });
          setListings(listings);
        };
        fetchUserListings();
      }, [auth.currentUser.uid]);
  return (
    <Layout title="History">
      <div className="container-fluid mt-4 your-listings">
        {listings && listings?.length > 0 && (
          <>
            <h6>History</h6>
            <div>
              {listings.map(listing => (
                <ListingItem
                  key={listing.id}
                  listing={listing.data} 
                  id={listing.id}
                  onMarkAvailable={() => onMarkAvailable(listing.id)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </Layout>
  )
}

export default History