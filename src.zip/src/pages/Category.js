
import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout/Layout';
import { useParams } from 'react-router-dom';
import { db } from '../firebase.config';
import { toast } from 'react-toastify';
import { collection, getDocs, query, where, orderBy, limit, startAfter } from 'firebase/firestore';
import ListingItem from '../components/ListingItem';
import { IoReloadCircle } from 'react-icons/io5';
import "../styles/category.css";

const Category = () => {
    const [listing, setListing] = useState(null);
    const [lastFetchListing,setLastFetchListing] = useState(null);
    const [loading, setLoading] = useState(true);
    const params = useParams();

    useEffect(() => {
        const fetchListing = async () => {
            try {
                const listingsRef = collection(db, 'listings');
                const q = query(
                    listingsRef,
                    where('type', '==', params.categoryName),
                    orderBy('timestamp', 'desc'),
                    limit(1)
                );
                const querySnap = await getDocs(q);
                const lastVisible = querySnap.docs[querySnap.docs.length -1]
                setLastFetchListing(lastVisible)
                const listings = [];
                querySnap.forEach((doc) => {
                   return listings.push({
                        id: doc.id,
                        data: doc.data(),
                    });
                });
                setListing(listings);
                setLoading(false);
            } catch (error) {
                console.error(error);
                toast.error('Unable to fetch data');
            }
        };
        fetchListing();
    }, [params.categoryName]);


    const fetchLoadMoreListing = async () => {
        try {
            const listingsRef = collection(db, 'listings');
            const q = query(
                listingsRef,
                where('type', '==', params.categoryName),
                orderBy('timestamp', 'desc'),
                startAfter(lastFetchListing),
                limit(2)
            );
            const querySnap = await getDocs(q);
            const lastVisible = querySnap.docs[querySnap.docs.length -1]
            setLastFetchListing(lastVisible)
            const listings = [];
            querySnap.forEach((doc) => {
               return listings.push({
                    id: doc.id,
                    data: doc.data(),
                });
            });
            setListing(prevState => [...prevState, ...listings]);
            setLoading(false);
        } catch (error) {
            console.error(error);
            toast.error('Unable to fetch data');
        }
    };

    return (
        <Layout title={params.categoryName === 'rent' ? "Places For Rent" : "Places For Sale"}>
            <div className="mt-3 container-fluid">
                <h1>{params.categoryName === 'rent' ? "Places For Rent" : "Places For Sale"}</h1>
                {loading ? (
                    <spinner/>
                    // Use the spinner class here
                ) : listing && listing.length > 0 ? (
                   
                    <div>
                        {listing.map((list) => (
                            <ListingItem listing={list.data} id={list.id} key={list.id} />
                        ))}
                    </div>
                    
                ) : (
                    <p>No Listings For {params.categoryName}</p>
                )}
            <div className='d-flex align-items-center justify-content-center pb-4 mt-4'>
  {lastFetchListing && (
    <button className='load-btn' onClick={fetchLoadMoreListing}>
      <IoReloadCircle/> Load more
    </button>
  )}
</div>
</div>
        </Layout>
    );
};

export default Category;