import React,{useState,useEffect,useRef} from 'react';
import { useNavigate } from 'react-router-dom';
import {v4 as uuidv4} from "uuid";
import Layout from './../components/Layout/Layout';
import { getAuth,onAuthStateChanged } from 'firebase/auth';
import Spinner from '../components/Spinner';
import Offers from './Offers';
import { AiOutlineFileAdd } from 'react-icons/ai'; 
import { toast } from 'react-toastify';
import {getStorage,ref,uploadBytesResumable,getDownloadURL} from "firebase/storage";
import { db } from '../firebase.config';

import {addDoc,collection,serverTimestamp} from "firebase/firestore";
const CreateListing = () => {
    const [loading,setLoading] = useState(false);
    const [geoLocationEnable,setGeoLocationEnable] = useState(false);
    const [formData,setFormData] = useState({
      type:'rent',
      name:'',
      bedrooms:1,
      bathrooms:1,
      parking:false,
      furnished:false,
      address:'',
      offer:false,
      regularPrice:0,
      discountedPrice:0,
      images:{},
      latitude:0,
      longitude:0,


    });

    const {
      type,
      name,
      bedrooms,
      bathrooms,
      parking,
      furnished,
      address,
      offer,
      regularPrice,
      discountedPrice,
      images,
      latitude,
      longitude,
    } = formData;

    const auth = getAuth();
    const navigate = useNavigate();
    const  isMounted = useRef(true);
    
    useEffect(() => {
      if(isMounted){
        onAuthStateChanged(auth,(user) =>{
          setFormData({
            ...formData,
            useRef: user.uid,
          });
        });
      }
      else  {
        navigate('/signin');
      }
    },[]);


    if(loading) {
      return <Spinner/>;
    }

    const onChangeHandler = (e)=>{
      let boolean = null;
      if(e.target.value === "true") {
        boolean = true;
      }
      if(e.target.value === "false") {
        boolean=false;
      }
      if(e.target.files) {
        setFormData((prevState) =>({
          ...prevState,
          images:e.target.files,
        }) );
      }
      if(!e.target.files) {
        setFormData((prevState) => ({
          ...prevState,
          [e.target.id]:boolean ?? e.target.value,
          //images: e.target.files,
        }));
      }
    };
    const onSubmit = async (e) => {
      setLoading(true);
      e.preventDefault();
      console.log(formData);
      if(discountedPrice>=regularPrice){
        setLoading(false)
        toast.error("Discount price should be less than Regular Price")
        return
      }
      // else{
      //   toast.error("ok")
      // }
      if(images > 6) {
        setLoading(false)
        toast.error("max 6 Images can be selected")
        return
      }
      
      let geoLocation = {};
      let location;
      if(geoLocationEnable){
        const response = await fetch("https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key= AIzaSyBePSBfdic0gLIvZA8J2lcdyInUewFp4DE ");
        const data = await response.json();
        console.log(data);
      }else{
        geoLocation.lat = latitude;
        geoLocation.lng = longitude;
     location = address;

      }
    const storeImage  = async (image) => {
      return new Promise((resolve,reject) =>{
        const storage = getStorage();
        const fileName = `${auth.currentUser.uid}-${image.name}-${uuidv4()}`;

        const storageRef = ref(storage,'image/'+fileName)
        const uploadTask = uploadBytesResumable(storageRef,image);
        uploadTask.on('state_changed',(snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log('upload is'+ progress+'% done');
          switch(snapshot.state){
            case 'paused' : console.log('upload is paused');
            break
            case 'running' : console.log('upload is running');
            
          }
        },
        (error)=> {reject(error)},
        ()=> {
          getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
            resolve(downloadURL);
          });
        });
      });
    };
    const  imgUrls = await Promise.all(
      [...images].map((image) => storeImage(image))
    ).catch(() => {
      setLoading(false);
      toast.error('Images not uploaded');
      return;
    });
    console.log(imgUrls);
    const formDataCopy = {
      ...formData,
      imgUrls,
      geoLocation,
      timestamp: serverTimestamp(),
  };
    
    formData.location = address;
    delete formDataCopy.images;
   // delete formDataCopy.address;
    !formDataCopy.offer && delete formDataCopy.discountedPrice;
    const docRef = await addDoc(collection(db, 'listings'), formDataCopy);
    toast.success("Listing Created!");
    setLoading(false);
    navigate(`/category/${formDataCopy.type}/${docRef.id}`);

    };

    return (
      <Layout>
        <div className='container d-flex flex-column align-items-center justify-center-center  mb-4'>
          <h3 className='mt-3 w-50  bg-dark text-light p-2 text-center'>
            Creat Listing  &nbsp;
            <AiOutlineFileAdd />
          </h3>
        
        <form className="w-50 bg-light p-4" onSubmit={onSubmit}>
          <div className='d-flex flex-row mt-4'>
            <div className='form-check'>
             <input 
             className='from-check-input'
             type="radio"
             value="rent"
             onChange={onChangeHandler}
             defaultChecked
             name="type"
             id="type"
             />
             <label className='form-check-label' htmlFor='rent'>
              Rent
             </label>
            </div>
            <div className='from-check ms-3'>
            <input 
             className='from-check-input'
             type="radio"
             value="sale"
             name="type"
             onChange={onChangeHandler}
             //defaultChecked
             id="type"
             />
             <label className='form-check-label' htmlFor='sale'>
              Sale
             </label>
            </div>
          </div>

          {/*name */}
          
          <div className='mb-3 mt-4 d-flex flex-column'>
          <label htmlFor='name' className='form-label'>
           Name:
          </label>
         <input  
           type="text"
           className='form-control'
           id="name"
           value={name}
           name="name" 
           onChange={onChangeHandler}
           required
          />
         </div>


          {/*bedrooms*/}
          <div className='mb-3 mt-4 d-flex flex-column'>
            <label htmlFor='bedrooms' className='form-label'>
              Bedrooms
            </label>
            <input  
             type="number"
             className='from-control'
             id="bedrooms"
             value={bedrooms}
             name="type"
             onChange={onChangeHandler}
             required
           />
          </div>
          
          {/*bathrooms*/}
          <div className='mb-3 mt-4 d-flex flex-column'>
            <label htmlFor='bathrooms' className='form-label'>
              Bathrooms
            </label>
            {/* <div className='d-flex flex-row'> */}
            <input  
             type="number"
             className='from-control'
             id="bathrooms"
             value={bathrooms}
             name="type"
             onChange={onChangeHandler}
             required
           />
          {/* </div> */}
          </div>
          
          
          {/*parking*/}
          <div className='mb-3 mt-4'>
            <label htmlFor='parking' className='form-label'>
              Parking :
            </label>
            <div className='d-flex flex-row'>
              <div className='form-check'>
            <input  
             
             className='from-check-input'
             type="radio"
             name="parking"
             value={false}
             defaultChecked
             onChange={onChangeHandler}
             id="parking"
           />
           <label className='form-check-label' htmlFor='no'>
            Yes
           </label>
          </div>

          <div className='form-check ms-3'>
            <input  
             
             className='from-check-input'
             type="radio"
             name="parking"
             value={false}
             defaultChecked
             onChange={onChangeHandler}
             id="parking"
           />
           <label className='form-check-label' htmlFor='no'>
            No
           </label>
          </div>

          </div>
          </div>

          {/*furnished*/}
          <div className='mb-3'>
            <label htmlFor='furnished' className='form-label'>
              Furnished :
            </label>
            <div className='d-flex flex-row'>
              <div className='form-check'>
            <input  
             className='from-check-input'
             type="radio"
             name="furnished"
             value={true}
             defaultChecked
             onChange={onChangeHandler}
             id="furnished"
           />
           <label className='form-check-label' htmlFor='yes'>
            Yes
           </label>
          </div>

          <div className='form-check ms-3'>
            <input  
             className='from-check-input'
             type="radio"
             name="furnished"
             value={true}
             defaultChecked
             onChange={onChangeHandler}
             id="furnished"
           />
           <label className='form-check-label' htmlFor='yes'>
            No
           </label>
          </div>
          
          </div>
          </div>

           {/*address*/}
           <div className='mb-3 d-flex flex-column'>
            <label htmlFor='address'>
              Address :
              </label> 
            <textarea 
             className='from-control'
             placeholder='Enter Your Address'
             id="address"
             value={address}
             onChange={onChangeHandler}
             required
           />
          </div>

          {/*geoLoaction*/}
        
{!geoLocationEnable && (
  <div className='mb-3'>
    <div className='d-flex flex-row'>
      <div className='form-check d-flex flex-column'>
        <label htmlFor='latitude' className='form-check-label'>
          Latitude:
        </label>
        <input  
          className='form-control'
          type="number"
          name="latitude"
          value={latitude}
          onChange={onChangeHandler}
          id="latitude"
        />
      </div>
      <div className='form-check ms-3 d-flex flex-column'>
        <label htmlFor='longitude' className='form-check-label'>
          Longitude:
        </label>
        <input  
          className='form-control'
          type="number"
          name="longitude"
          value={longitude}
          onChange={onChangeHandler}
          id="longitude"
        />
      </div>
    </div>
  </div>
)}


          {/*offers*/}
          <div className='mb-3'>
            <label htmlFor='offers' className='form-label'>
            Offers :
            </label>
            <div className='d-flex flex-row'>
           <div className='form-check'>
            <input  
             className='from-check-input'
             type="radio"
             value={true}
             onChange={onChangeHandler}
             name="offer"
             id="offer"
           />
           <label htmlFor='yes' className='form-check-label'>
            yes 
            </label>
            </div>
           <div className='form-check ms-3'>
            <input  
             className='from-check-input'
             type="radio"
             value={false}
             onChange={onChangeHandler}
             name="offer"
             id="offer"
           />
           <label htmlFor='no' className='form-check-label'>
           No 
           </label>
          </div>
          </div>
          </div>
          
        {/*regular price*/}
        <div className='mb-3 mt-4'>
            <label htmlFor='name' className='form-label'>
              Regular Price :
            </label>
            <div className='d-flex flex-row'>
            <input  
             type="number"
             className='from-control w-50 '
             id="regularPrice"
             value={regularPrice}
             name="regularPrice"
             onChange={onChangeHandler}
             required
           />
           {type === "rent" && <p className='ms-4 mt-2'>₹ /Month</p>}
           </div>
          </div>
          {/* offer */}
          {offer && (
            <div className='mb-3 mt-4 d-flex flex-column'>
              <label htmlFor='discountedPrice' className='form-label'>
              Discounted Price :
            </label>
            
            <input  
             type="number"
             className='from-control w-50 '
             id="discountedPrice"
             value={discountedPrice}
             name="discountedPrice"
             onChange={onChangeHandler}
             required
           />
           
          </div>
          )}

          {/* files images etc*/}
          <div className='mb-3'>
          <label htmlFor='formfile' className='form-label'>
            Select image :
          </label>
          <input 
          className='form-control'
          type='file'
          id='images'
          name='images'
          onChange={onChangeHandler}
          max='6'
          accept='.jpg,.png,.jpeg'
          multiple
          required
          />
          </div>
          {/* submit button */}
          <div   className='mb-3'>
            <input
            disabled={!name || !address || !regularPrice || !images}
            className='btn btn-primary w-100'
            type='submit'
            value='Create Listing'
            />
          </div>
        </form>
        </div>
      </Layout>
    );
};

export default CreateListing;