import React from 'react';
import {useNavigate} from "react-router-dom"
import Layout from '../components/Layout/Layout';
import Slider from '../components/Slider';
import "../styles/homepage.css"

const HomePage = () => {
 const navigate= useNavigate()
  const img1 = "https://th.bing.com/th/id/OIP.AwfaMasMKA_vVki2m3l3lwHaEx?rs=1&pid=ImgDetMain";
   const img2 = "https://ak.picdn.net/shutterstock/videos/1018456078/thumb/1.jpg?ip=x480";
  //  const img2="https://thumbs.dreamstime.com/b/hand-holding-house-22355432.jpg"
  //00const img3 = "https://wallpaperaccess.com/full/2315968.jpg"

  return (
    <Layout>
      <Slider/>
<div>
      <div className='home-cat row d-flex align-items-center justify-content-center'>
          <h1>Category</h1>
      
          <div className='col-md-5'>
            <div className="Imagecontainer">
              <img src={img1} alt="Rent" style={{ width: "100%" }} />
              <button className='btn' 
              onClick={() => navigate('/category/rent')}
              >FOR RENT</button>
            </div>
          </div>  

          <div className='col-md-5'>
            <div className="Imagecontainer">
              <img src={img2} alt="Sale" style={{ width: "100%" }} />
              <button className='btn'
              onClick={() => navigate('/category/sale')}
              >FOR SALE</button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HomePage;

