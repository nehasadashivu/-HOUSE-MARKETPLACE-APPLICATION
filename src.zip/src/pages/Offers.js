import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout/Layout';
import { useParams } from 'react-router-dom';
import { db } from '../firebase.config';
import { toast } from 'react-toastify';
import { collection, getDocs, query, where, orderBy, limit,startAfter } from 'firebase/firestore';
import ListingItem from '../components/ListingItem';
import { IoReloadCircle } from 'react-icons/io5';
import "../styles/offers.css";
//import Offers from './Offers';

const Offers = () => {
  const [listing, setListing] = useState(null);
    const [loading, setLoading] = useState(true);
    const [lastFetchListing,setLastFetchListing] = useState(null)
    const params = useParams();

    useEffect(() => {
        const fetchListing = async () => {
            try {
                const listingsRef = collection(db, 'listings');
                const q = query(
                    listingsRef,
                    where('offer', '==', true),
                    orderBy('timestamp', 'desc'),
                    limit(2)
                );
                const querySnap = await getDocs(q);
                const lastVisible = querySnap.docs[querySnap.docs.length -1];
                setLastFetchListing(lastVisible);
                const listings = [];
                querySnap.forEach((doc) => {
                    listings.push({
                        id: doc.id,
                        data: doc.data(),
                    });
                });
                setListing(listings);
                setLoading(false);
            } catch (error) {
                console.error(error);
                toast.error('Unable to fetch data');
            }
        };
        fetchListing();
    }, []);
    const fetchLoadMoreListing = async () => {
        try {
            const listingsRef = collection(db, 'listings');
            const q = query(
                listingsRef,
                where('offer', '==', true),
                orderBy('timestamp', 'desc'),
                startAfter(lastFetchListing),
                limit(2)
            );
            const querySnap = await getDocs(q);
            const lastVisible = querySnap.docs[querySnap.docs.length -1]
            setLastFetchListing(lastVisible)
            const listings = [];
            querySnap.forEach((doc) => {
               return listings.push({
                    id: doc.id,
                    data: doc.data(),
                });
            });
            setListing(prevState => [...prevState, ...listings]);
            setLoading(false);
        } catch (error) {
            console.error(error);
            toast.error('Unable to fetch data');
        }
    };

  return (
    <Layout title="best offer on house">
    <div className="offers pt-3 container-fluid">
        <h1>
            { " "}
            <img 
            src ="/assets/best.png"
            alt ="offers"
            className='offers-img'
            /> {" "}
            Best Offers
        </h1>
        
        {loading ? (
            <div className="spinner" />
        ) : listing && listing.length > 0 ? (
            <div>
                {listing.map((list) => (
                    <ListingItem listing={list.data} id={list.id} key={list.id} />
                ))}
            </div>
        ) : (
            <p>There Are No Current Offer</p>
        )}
    
    {/* <div className='d-flex align-items-center justify-content-center pb-4 mt-4'>
                {
                    lastFetchListing && (
                        <button className='load-btn'
                        onClick={fetchLoadMoreListing}
                        ><IoReloadCircle/>load more</button>
                    )
                }
            </div> */}
            <div className='d-flex align-items-center justify-content-center pb-4 mt-4'>
  {lastFetchListing && (
    <button className='load-btn' onClick={fetchLoadMoreListing}>
      <IoReloadCircle/> Load more
    </button>
  )}
</div>
            </div>
</Layout>
  )
}

export default Offers;